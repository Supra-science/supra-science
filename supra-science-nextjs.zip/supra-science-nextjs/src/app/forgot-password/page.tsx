 "use client";
import Link from "next/link";
import {FormEvent,useState} from "react";
import {createClient} from "@/lib/supabase/client";
export default function ForgotPasswordPage(){
 const[email,setEmail]=useState("");const[message,setMessage]=useState("");const[error,setError]=useState("");
 async function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();setError("");setMessage("");const{error}=await createClient().auth.resetPasswordForEmail(email,{redirectTo:`${window.location.origin}/auth/callback?next=/reset-password`});if(error)setError(error.message);else setMessage("If an account exists for this address, a password reset link has been sent.");}
 return <main className="shell"><nav className="nav"><Link href="/" className="brand"><span className="brandmark">S</span>SUPRA<span className="gold">-SCIENCE</span></Link><Link href="/login" className="muted">Back to sign in</Link></nav><div className="authwrap"><section className="panel authcard"><div className="eyebrow">Account recovery</div><h1>Reset your <span className="gold">password.</span></h1><form onSubmit={submit}><div className="field"><label htmlFor="email">Email address</label><input id="email" type="email" required value={email} onChange={e=>setEmail(e.target.value)}/></div>{error&&<p className="error">{error}</p>}{message&&<p className="success">{message}</p>}<button className="btn" style={{width:"100%"}}>Send reset link</button></form></section></div></main>
}