import Link from "next/link";
import {redirect} from "next/navigation";
import {createClient} from "@/lib/supabase/server";
export default async function AdminPage(){
 const supabase=await createClient();const{data:{claims}}=await supabase.auth.getClaims();if(!claims?.sub)redirect("/login");
 const{data:role}=await supabase.from("user_roles").select("role").eq("user_id",claims.sub).maybeSingle();if(role?.role!=="admin")redirect("/dashboard");
 const{count}=await supabase.from("profiles").select("*",{count:"exact",head:true});
 async function signOut(){"use server";const client=await createClient();await client.auth.signOut();redirect("/login");}
 return <main className="shell"><nav className="nav"><Link href="/" className="brand"><span className="brandmark">S</span>SUPRA<span className="gold">-SCIENCE</span></Link><form action={signOut}><button className="btn secondary">Sign out</button></form></nav><section className="dashboard"><div className="eyebrow">Restricted · Administrator</div><h1 style={{fontSize:46}}>Control <span className="gold">center.</span></h1><p className="lead">Administrator access verified against the private user_roles table.</p><div className="tiles"><article className="tile"><h3>Registered profiles</h3><strong className="gold" style={{fontSize:32}}>{count??"—"}</strong></article><article className="tile"><h3>Access control</h3><p className="muted">Role-based access is enforced server-side and by database policies.</p></article><article className="tile"><h3>Platform identity</h3><p className="muted">Managed by D. Faisal Alradaei</p></article></div><p style={{marginTop:28}}><Link className="btn secondary" href="/dashboard">Back to workspace</Link></p></section></main>
}