import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Supra-Science | Intelligent Engineering",
  description: "Supra-Science — engineering, software, AI and scientific innovation."
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}