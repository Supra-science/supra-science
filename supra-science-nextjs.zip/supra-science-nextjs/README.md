# Supra-Science

Next.js App Router application using Supabase Auth and server-side authorization.

## Environment
Copy `.env.example` to `.env.local`. The publishable key is designed for browser use. Never expose a Supabase secret/service-role key in `NEXT_PUBLIC_*`.

## Run
```bash
npm install
npm run dev
```

## Routes
- `/` brand landing page
- `/login`, `/signup`, `/forgot-password`, `/reset-password`
- `/dashboard` authenticated clients
- `/admin` private administrator console

## Supabase setup
The connected project already has `profiles` and `user_roles` tables with RLS. New registrations are assigned `customer`; the allowlisted owner email `goodyour583@gmail.com` is assigned `admin` by a database trigger. Do not allow clients to update `user_roles`.

## Deployment
Configure the environment variables in the hosting provider. Add the deployed site origin to Supabase Auth URL Configuration and add `/auth/callback` to allowed redirects. Enable email confirmation before public launch.
